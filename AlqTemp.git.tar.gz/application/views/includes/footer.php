<div class="left">
    Copyright &copy; 2009 Alquilerestemporarios.org<br/>
    <span>Dise&ntilde;o y Desarrollo by</span>
    <a href="http://www.mydesign.com.ar" target="_blank"><img src="images/marca_mydesign_miniatura.png" alt="www.mydesign.com.ar" /></a>
</div>

<div class="rigth">
    <a href="#">Site Map</a> | <a href="#">Publicidad</a> | <a href="#">Cont&aacute;tenos</a>
    <br />
    <span><a href="#">Condiciones de Uso</a> | <a href="#">Pol&iacute;ticas de Privacidad</a></span>
</div>

<p>&nbsp;</p>