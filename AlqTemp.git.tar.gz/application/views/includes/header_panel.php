    <div class="top_left">
        <div class="top_menu">
            <ul>
                <li><a href="index.php"><img src="images/icono_inicio.png" alt="inicio" border="0" /> Inicio</a></li>
                <li><a href="contacto.php"><img src="images/icono_contacto.png" alt="contacto" border="0" />Contacto</a></li>
            </ul>
        </div>
        <div class="logo"><img src="images/logo_alquilerestemp.png" alt="www.alquilerestemporarios.org" border="0" /> </div>
    </div>

    <div class="top_right">
        <div class="registro">
            <form name="formLogin" id="formLogin" action="<?=site_url('/login/');?>" enctype="application/x-www-form-urlencoded" method="post">
                <input type="text" value="Usuario" class="input_login" />
                <input type="password" value="Contrase&ntilde;a" class="input_login" />
                <a href="#"><input type="submit" value="login" class="login"/></a>
            </form>
        </div>
    </div>

    <div class="column_panel">
        <div class="menu_panel">
            <ul>
                <li><a href="#">Propiedades</a></li>
                <li><a href="#">Servicios Premium</a></li>
                <li><a href="mi_cuenta.php">Mi Cuenta</a></li>
                <li><a href="comprar_creditos.php">Comprar Creditos</a></li>
            </ul>
        </div>
    </div>
